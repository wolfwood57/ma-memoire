# Ma Mémoire V1.1 — Android

Version native Android de démonstration, pensée pour être compilée dans GitHub Actions sans installer Flutter sur le téléphone.

Fonctions :
- 🎙️ dictée vocale en français (`fr-FR`)
- 📝 transcription éditable
- 💾 sauvegarde locale des souvenirs
- 🔎 recherche dans les souvenirs
- 📅 date et heure de chaque mémoire

## Compilation sans PC

1. Créer un dépôt GitHub.
2. Envoyer tous les fichiers de ce projet dans le dépôt.
3. Ouvrir l'onglet **Actions**.
4. Lancer **Build Ma Memoire APK** avec **Run workflow**.
5. Quand le travail est terminé, ouvrir le résultat et télécharger l'artifact **Ma-Memoire-V1.1-APK**.
6. Télécharger `app-debug.apk` sur le téléphone et l'installer.

Le workflow utilise Java 17, le SDK Android et Gradle sur le serveur GitHub.

## Important

C'est une V1.1 fonctionnelle de capture mémoire. Les données restent sur le téléphone. La reconnaissance vocale dépend du service de reconnaissance installé/activé sur Android.
